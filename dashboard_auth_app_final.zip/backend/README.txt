Dashboard Auth App (Auth + Persistence + Deploy)

Backend:
- app.py (Flask API with endpoints: /register, /login, /user/<username>, /transaction, /transactions/<username>)
- data.json (created on first run)
- requirements.txt
- render.yaml (one-click deploy to Render)

Frontend:
- index.html, login.html, register.html
- script.js (handles auth flow and dashboard interactions)
- style.css

Run locally:
1. cd backend
2. pip install -r requirements.txt
3. python app.py
4. Open frontend/login.html in your browser and register/login

Deploy:
- For backend: create a new Web Service on Render, connect this backend folder (or push to GitHub and link)
- For frontend: push frontend folder to a GitHub repo and enable GitHub Pages
