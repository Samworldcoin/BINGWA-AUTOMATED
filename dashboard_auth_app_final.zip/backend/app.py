from flask import Flask, request, jsonify
from flask_cors import CORS
import json, os, bcrypt, threading
from datetime import datetime

app = Flask(__name__)
CORS(app)

DATA_FILE = os.path.join(os.path.dirname(__file__), 'data.json')
lock = threading.Lock()

def load_data():
    if not os.path.exists(DATA_FILE):
        with open(DATA_FILE, 'w') as f:
            json.dump({'users': {}}, f)
    with open(DATA_FILE, 'r') as f:
        return json.load(f)

def save_data(data):
    with lock:
        with open(DATA_FILE, 'w') as f:
            json.dump(data, f, indent=2)

@app.route('/register', methods=['POST'])
def register():
    data = load_data()
    req = request.get_json() or {}
    username = req.get('username', '').strip()
    password = req.get('password', '').strip()
    if not username or not password:
        return jsonify({'message': 'Username and password required'}), 400
    if username in data['users']:
        return jsonify({'message': 'User already exists'}), 400
    hashed = bcrypt.hashpw(password.encode('utf-8'), bcrypt.gensalt()).decode('utf-8')
    data['users'][username] = {'password': hashed, 'balance': 0.0, 'commission': 0.0, 'transactions': []}
    save_data(data)
    return jsonify({'message': 'Registration successful'}), 200

@app.route('/login', methods=['POST'])
def login():
    data = load_data()
    req = request.get_json() or {}
    username = req.get('username', '').strip()
    password = req.get('password', '').strip()
    user = data['users'].get(username)
    if not user:
        return jsonify({'message': 'User not found'}), 404
    if not bcrypt.checkpw(password.encode('utf-8'), user['password'].encode('utf-8')):
        return jsonify({'message': 'Incorrect password'}), 401
    return jsonify({'message': 'Login successful'}), 200

@app.route('/user/<username>', methods=['GET', 'POST'])
def user_data(username):
    data = load_data()
    if username not in data['users']:
        return jsonify({'message': 'User not found'}), 404
    if request.method == 'GET':
        user = data['users'][username].copy()
        user.pop('password', None)
        return jsonify(user)
    else:
        update = request.get_json() or {}
        # don't allow password updates through this endpoint
        update.pop('password', None)
        data['users'][username].update(update)
        save_data(data)
        return jsonify({'message': 'User updated'}), 200

@app.route('/transaction', methods=['POST'])
def add_transaction():
    data = load_data()
    req = request.get_json() or {}
    username = req.get('username', '').strip()
    amount = float(req.get('amount', 0.0))
    status = req.get('status', 'Pending')
    if username not in data['users']:
        return jsonify({'message': 'User not found'}), 404
    txns = data['users'][username].setdefault('transactions', [])
    txn = {'id': len(txns) + 1, 'amount': amount, 'status': status, 'time': datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
    txns.append(txn)
    if status.lower() == 'successful':
        data['users'][username]['commission'] = round(data['users'][username].get('commission', 0.0) + amount * 0.05, 2)
        data['users'][username]['balance'] = round(data['users'][username].get('balance', 0.0) + amount, 2)
    save_data(data)
    return jsonify({'message': 'Transaction added', 'transaction': txn}), 200

@app.route('/transactions/<username>', methods=['GET'])
def get_transactions(username):
    data = load_data()
    if username not in data['users']:
        return jsonify({'message': 'User not found'}), 404
    return jsonify(data['users'][username].get('transactions', []))

if __name__ == '__main__':
    app.run(debug=True)
