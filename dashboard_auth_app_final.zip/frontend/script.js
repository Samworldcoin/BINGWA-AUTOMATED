const API_URL = "http://127.0.0.1:5000";

// Auth pages behavior
document.addEventListener('DOMContentLoaded', () => {
  const path = window.location.pathname.split('/').pop();
  if (path === 'register.html') {
    document.getElementById('regBtn').addEventListener('click', async () => {
      const username = document.getElementById('regUsername').value.trim();
      const password = document.getElementById('regPassword').value.trim();
      if (!username || !password) return alert('Enter username and password');
      const res = await fetch(`${API_URL}/register`, {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({username, password})
      });
      const data = await res.json();
      if (!res.ok) return alert(data.message || 'Error');
      alert('Registered successfully. Please login.');
      window.location.href = 'login.html';
    });
  } else if (path === 'login.html') {
    document.getElementById('loginBtn').addEventListener('click', async () => {
      const username = document.getElementById('loginUsername').value.trim();
      const password = document.getElementById('loginPassword').value.trim();
      if (!username || !password) return alert('Enter username and password');
      const res = await fetch(`${API_URL}/login`, {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({username, password})
      });
      const data = await res.json();
      if (!res.ok) return alert(data.message || 'Login failed');
      localStorage.setItem('username', username);
      window.location.href = 'index.html';
    });
  } else {
    // Dashboard page
    const username = localStorage.getItem('username');
    if (!username) {
      window.location.href = 'login.html';
      return;
    }
    document.getElementById('greeting').textContent = `Welcome, ${username}`;
    loadUser(username);
    loadTransactions(username);

    document.getElementById('playBtn').addEventListener('click', async () => {
      const amt = parseFloat(prompt('Enter transaction amount (Ksh):'));
      if (isNaN(amt)) return alert('Invalid amount');
      const res = await fetch(`${API_URL}/transaction`, {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({username, amount: amt, status: 'Successful'})
      });
      if (!res.ok) return alert('Transaction failed');
      await loadUser(username);
      await loadTransactions(username);
    });
  }
});

async function loadUser(username) {
  const res = await fetch(`${API_URL}/user/${username}`);
  if (!res.ok) return;
  const data = await res.json();
  document.getElementById('commissionText').textContent = `This week's commission (Ksh. ${Number(data.commission || 0).toFixed(2)})`;
  document.getElementById('airtimeBalance').innerHTML = `Airtime Balance<br>Ksh ${Number(data.balance || 0).toFixed(2)} 👁️`;
}

async function loadTransactions(username) {
  const res = await fetch(`${API_URL}/transactions/${username}`);
  if (!res.ok) return;
  const data = await res.json();
  const el = document.getElementById('transactionsList');
  if (!Array.isArray(data) || data.length === 0) {
    el.textContent = 'No transactions yet.';
    return;
  }
  el.innerHTML = data.map(t => `#${t.id} - ${t.status} (Ksh. ${t.amount}) - ${t.time}`).join('<br>');
}

function logout() {
  localStorage.removeItem('username');
  window.location.href = 'login.html';
}
