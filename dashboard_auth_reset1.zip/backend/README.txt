Dashboard Auth App with Email Password Reset

Backend environment variables (required for real email sending):
- SECRET_KEY (optional, default in app)
- MAIL_SERVER (defaults to smtp.gmail.com)
- MAIL_PORT (defaults to 587)
- MAIL_USE_TLS (True/False)
- MAIL_USERNAME (your email)
- MAIL_PASSWORD (app password or SMTP password)
- MAIL_DEFAULT_SENDER (optional)

Run locally:
1. cd backend
2. pip install -r requirements.txt
3. set the env vars (example for Linux/macOS):
   export MAIL_USERNAME='you@gmail.com'
   export MAIL_PASSWORD='your_app_password'
   export SECRET_KEY='some-secret'
4. python app.py

If mail send fails, the API will return the reset URL in the response (useful for testing).
